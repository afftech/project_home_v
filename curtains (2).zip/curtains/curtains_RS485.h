#include <curtains_control.h>
class Curtains {
public:
  Curtains(int x) {  //255 MAX
    this->numberCurtains = x;
    for (int i = 0; i < this->numberCurtains; i++) { curtainsObj[i] = new CurtainsObj(i + 1); }
  }

  void loop() {

    switch (state) {
      case WAIT_DATA:
        //getDataFromUART();
        break;
      case SEND_DATA:
        state = WAIT_DATA;
        break;
    }
    if (millis() - Time_Wait >= 100) {
      Time_Wait = millis();
      curtainsObj[addres_Pos]->loop();
      addres_Pos++;
      if (addres_Pos == numberCurtains) {
        addres_Pos = 0;
      }
    }
  }
  void send(int addres, char message) {
    state = SEND_DATA;
    addres = addres - 1;
    //delay(50);  // надо будет убрать и заменить!!!
    switch (message) {
      /*case 'p':
        curtainsObj[addres]->setterBlinds(data);
        break;*/
      case 's':
        curtainsObj[addres]->Stop();
        break;
      case 'u':
        curtainsObj[addres]->setterBlinds(99);
        break;
      case 'd':
        curtainsObj[addres]->setterBlinds(0);
        break;
      default:
        break;
    }
    //delay(50);  // надо будет убрать и заменить!!!
  }
  void getDataFromUART() {
    byte incomingBytesRead = 0;
    while (Serial2.available() > 0) {
      incomingData[incomingBytesRead++] = Serial2.read();
      ;
      //delay(5);
    }
    if (incomingBytesRead) {
      bytesCount = incomingBytesRead;
      state = PARSING_DATA;
    }
  }
private:
  uint32_t Time_Wait;
  int addres_Pos = 0;
  int numberCurtains = 1;
  CurtainsObj* curtainsObj[32];  // Изменить
  byte bytesCount = 0;
  byte incomingData[INCOMING_BYTES_COUNT];
  byte state = WAIT_DATA;
  byte commandToSend;

  unsigned long lastLevelRequest = 0;
};